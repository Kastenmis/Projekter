import car_protocols as car_p
import UDP

def main():

    mode = ""
    mode_message = UDP.receive_UDP()
    if mode_message[0] == "mode":
        mode = mode_message[1]

    loop = True

    while loop:
        UDP.send_message()
        if mode == "sumo":
            # Run 'sumo' protocol
            loop = car_p.sumo()
        elif mode == "follow_wall":
            # Run 'follow wall' protocol
            loop = car_p.following_wall()
        elif mode == "remote_controled":
            # Run car on remotre control
            loop = car_p.remote_controled(UDP.receive_UDP())
        else:
            # Break loop to select new protocol
            loop = False


UDP.connect_wifi()

while True:
    main()

