import socket
from time import sleep
import network
import sensor_module as sens

ssid = "ITEK 2nd"
password = "2nd_Semester_F24v"

#IP på Raspberry PI Pico.
CAR_IP = "10.120.0.20"
UDP_PORT = 5005  # Port på Raspberry (skal også sættes til samme i raspberry pi python script)

COMPUTER_IP = '10.120.0.43'
Computer_port = 5001
sock = socket.socket(socket.AF_INET,  # Internet
                     socket.SOCK_DGRAM)  # UDP
sock.bind((CAR_IP, UDP_PORT))

#Forbinder til Wi-fi.
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)
    while not wlan.isconnected():
        print("Waiting for connection")
        sleep(1)
    print(wlan.ifconfig())

#Sender UDP pakker til target - Computer.
def send_message():
    val = f"{sens.read_Power()}".encode()
    sock.sendto(bytes(val, 'utf-8'), (COMPUTER_IP, Computer_port))

#Lytter efter UDP beskeder tilrettet mod Pico.
def receive_UDP():
    message = sock.recv(100)
    command = message.decode()
    com_input = command.split("\n")
    return com_input
