from time import sleep
import motor
import sensor_module as sens
import servo

def following_wall():

    #Tjekker om knappen bliver trykket og loop ændres til False
    if sens.check_button() == 0:
        motor.stop_right()
        motor.stop_left()
        return False

    distance = sens.getDistance()
    #Justerer bilen, hvis distancen er under 20.
    if distance <= 20:
        motor.right_forward(.5)
        motor.left_backward(.5)
    #Justerer bilen til venstre, hvis distancen er over eller lig med 80.
    elif distance >= 80:
        motor.left_forward(.75)
        motor.right_forward(.55)
    # Justerer bilen til højre, hvis distancen er mellem 40 og 80.
    elif distance < 80 and distance >= 40:
        motor.right_forward(.55)
        motor.left_forward(.65)
    #Justerer bilen til højre, hvis ingen af de tidligere betingelser er opfyldt.
    else:
        motor.right_forward(.65)
        motor.left_forward(.55)

    return True

def sumo():

    #tjekker om knappen bliver trykket og om loop ændres til False
    if sens.check_button() == 0:
        motor.stop_right()
        motor.stop_left()
        return False

    distance = sens.getDistance()
    colour = sens.readColour()

    #her defineres hvilken distance og ref værdi der kræves for at bilen reagere og køre fremad
    if distance > 150 and colour < 55000:
        motor.left_forward(.5)
        motor.right_backward(.45)
    elif distance <= 150:
        motor.stop_right()
        motor.stop_left()
        servo.foulplay()
        ref = 0
        #her defineres hvilken ref værdi bilen skal stoppe ved, og repositionere sig
        while ref < 55000:
            ref = sens.readColour()
            motor.right_forward(.6)
            motor.left_forward(.6)
        motor.stop_right()
        motor.stop_left()
        servo.fairplay()
        sleep(.5)
        #starter med at køre direkte bagud
        motor.right_backward(.75)
        motor.left_backward(.75)
        sleep(1)
        #køre herefter bagud til venstre
        motor.left_backward(.46)
        motor.right_backward(.75)
        sleep(.4)


    return True


def remote_controled(command):
    if command[0] == "QUIT":
        motor.stop_right()
        motor.stop_left()
        return False

    if command[0] == '0' and command [1] == '0': #Hvis vi modtager 0 i det analoge input, står den stille.
        motor.stop_right()
        motor.stop_left()
    elif command[0] == '0' and command [1] == '1': #Hvis det analoge input er 1 så kører den fremad på begge hjul
        left_speed = .9
        right_speed = .9
        motor.right_forward(right_speed)
        motor.left_forward(left_speed)
    elif command[0] == '0' and command [1] == '-1': #his det analoge input er = -1 bakker den tilbage på begge hjul
        left_speed = .9
        right_speed = .9
        motor.right_backward(right_speed)
        motor.left_backward(left_speed)
    elif command[0] == '1' and command [1] == '0': #Dreje om sig selv Mod uret
        left_speed = .8
        right_speed = .8
        motor.right_forward(right_speed)
        motor.left_backward(left_speed)
    elif command[0] == '-1' and command [1] == '0': #drej om sig selv med uret
        left_speed = .8
        right_speed = .8
        motor.right_backward(right_speed)
        motor.left_forward(left_speed)
    elif command[0] == '-1' and command [1] == '1': #Frem til højre
        left_speed = .9
        right_speed = .7
        motor.right_forward(right_speed)
        motor.left_forward(left_speed)
    elif command[0] == '1' and command [1] == '1': #Frem til venste
        left_speed = .7
        right_speed = .9
        motor.right_forward(right_speed)
        motor.left_forward(left_speed)
    elif command[0] == '-1' and command [1] == '-1': #Bag ud til højre
        left_speed = .9
        right_speed = .7
        motor.right_backward(right_speed)
        motor.left_backward(left_speed)
    elif command[0] == '1' and command [1] == '-1': #Bagud til venstre
        left_speed = .7
        right_speed = .9
        motor.right_backward(right_speed)
        motor.left_backward(left_speed)

    if command[2] == '1': #Armen kører nede fra og op, til ned igen
        servo.vold()
    if command[3] == '1': #armen går op, hvis den er nede, og gør intet hvis ikke den er i anden position
        servo.fairplay()
    if command[4] == '1': #armen kører ned og er er klar til at bruge kommandoen kaldet Vold
        servo.foulplay()

    return True
