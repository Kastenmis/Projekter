import PySimpleGUI as sg
import socket

robot_ip =  "10.120.0.20" #Robotbils Ip adresse
robot_port = 5005  # Portnummer for vores GUI

ssid = "ITEK 2nd"
password = "2nd_Semester_F24v"

print("UDP target IP: %s" % robot_ip)
print("UDP target port: %s" % robot_port)

sock = socket.socket(socket.AF_INET,  # Internet
                     socket.SOCK_DGRAM)  # UDP


def set_mode(mode):
    sock.sendto(bytes(f"mode\n{mode}", 'utf-8'), (robot_ip, robot_port))

def receive_UDP():
    HOST = "10.120.0.43"
    PORT = 5001
    sock = socket.socket(socket.AF_INET,  # Internet
                         socket.SOCK_DGRAM)  # UDP
    sock.settimeout(2)
    sock.bind((HOST, PORT))
    try: data,add = sock.recvfrom(1024)
    except:
        print("No message received")
        return
    print(data.decode())
    return float(data.decode())

def voltage_to_percentage():
    voltage = 10 * receive_UDP()

    max_voltage = 8.4
    min_voltage = 2.8
    voltage = max(min(voltage, max_voltage), min_voltage)

    percentage = (voltage - min_voltage) / (max_voltage - min_voltage) * 100
    percentage = round(percentage, 2)
    return percentage



#selve vores GUI layout
layout = [
    [sg.Text('Robotbil Kontrol', font=('Helvetica', 20))],
    [sg.Button('Sumo Program', size=(20, 2), font=('Helvetica', 14)), sg.Button('Fodbold Program', size=(20, 2), font=('Helvetica', 14)), sg.Button('Wall Follow Program', size=(20, 2), font=('Helvetica', 14))],
    [sg.Button ('Update battery', size = (20,2))],
    [sg.Text('Batteriniveau: Afventer værdi', key='battery_level', font=('Helvetica', 16))],
]

window = sg.Window('Robotbil Kontrolpanel', layout, size=(800, 400))

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED:
        break
    elif event == 'Sumo Program':
        set_mode("sumo")
    elif event == 'Fodbold Program':
        set_mode("remote_controled")
    elif event == 'Wall Follow Program':
        set_mode("follow_wall")
    elif event == "Update battery":
        window['battery_level'].update(f"Batteriniveau: {voltage_to_percentage()}%")
