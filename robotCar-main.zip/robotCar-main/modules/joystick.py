import pygame
import socket

pygame.init()

pygame.joystick.init()

joystick = pygame.joystick.Joystick(0) #Initialiserer joysticket.
joystick.init() #Starter joysticket.

sock = socket.socket(socket.AF_INET,  #Opretter en socket til netværkskommunikation.
                     socket.SOCK_DGRAM)

pico_ip = '10.120.0.22' #IP-adressen for destinationen.
pico_port = 5005 #Portnummeret for destinationen.

#Dictionary til at mappe knapnumre til navne.
button_names = {
    0: 'Triangle',
    1: 'Circle',
    2: 'Cross',
    3: 'Square',
    4: 'L1',
    5: 'R1',
    6: 'L2',
    7: 'R2',
    8: 'Select',
    9: 'Start',
}

#Dictionary til at holde styr på knapværdier.
button_values = {0: 0,
                 1: 0,
                 "Triangle": 0,
                 "Circle": 0,
                 "Cross": 0,
                 "Square": 0}


try:
    while True:
        for event in pygame.event.get(): #Gennemgår alle begivenheder i pygame event-køen.
            if event.type == pygame.JOYBUTTONDOWN: #Håndterer knaptryk og sender knapværdier til destinationen.
                button_name = button_names.get(event.button, 'Unknown Button')
                button_values[button_name] = 1
                sock.sendto(bytes(f"{button_values[0]}\n{button_values[1]}\n{button_values['Triangle']}\n{button_values['Circle']}\n{button_values['Cross']}\n{button_values['Square']}", 'utf-8'), (pico_ip, pico_port))
            elif event.type == pygame.JOYBUTTONUP: #Håndterer knapfrigivelser og sender knapværdier til destinationen.
                button_name = button_names.get(event.button, 'Unknown Button')
                if button_name == "R1":
                    sock.sendto(bytes("QUIT", 'utf-8'), (pico_ip, pico_port))
                else:
                    button_values[button_name] = 0
                    sock.sendto(bytes(f"{button_values[0]}\n{button_values[1]}\n{button_values['Triangle']}\n{button_values['Circle']}\n{button_values['Cross']}\n{button_values['Square']}", 'utf-8'), (pico_ip, pico_port))
            elif event.type == pygame.JOYAXISMOTION: #Håndterer joystick-bevægelser og sender knapværdier til destinationen.
                axis = event.axis
                value = round(-1 * joystick.get_axis(event.axis))
                button_values[axis] = value
                sock.sendto(bytes(f"{button_values[0]}\n{button_values[1]}\n{button_values['Triangle']}\n{button_values['Circle']}\n{button_values['Cross']}\n{button_values['Square']}", 'utf-8'), (pico_ip, pico_port))


finally:
    pygame.quit()
