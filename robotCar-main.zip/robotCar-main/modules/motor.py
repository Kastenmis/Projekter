from machine import Pin, PWM

frequency = 3000
dutycycle = 0.8


# Definerer pins til motor.
motor1_forward_pin = Pin(0, Pin.OUT)
motor1_backward_pin = Pin(1, Pin.OUT)
motor2_forward_pin = Pin(2, Pin.OUT)
motor2_backward_pin = Pin(3, Pin.OUT)

#Opretter PWM-objekt til højre motor.
right_pwm = PWM(Pin(4))
right_pwm.freq(frequency)
right_pwm.duty_u16(int(65536 * dutycycle))

#Opretter PWM-objekt til venstre motor.
left_pwm = PWM(Pin(5))
left_pwm.freq(frequency)
left_pwm.duty_u16(int(65536 * dutycycle))

#Sætter dutycycle for højre motor.
def right_forward(pmw_right):
    right_pwm.duty_u16(int(65536 *pmw_right))
    motor1_backward_pin.off()
    motor1_forward_pin.on()

#Sætter dutycycle for venstre motor.
def left_forward(pwm_left):
    left_pwm.duty_u16(int(65536 * pwm_left))
    motor2_backward_pin.off()
    motor2_forward_pin.on()

#Sætter dutycycle for højre motor.
def right_backward(pwm_right):
    right_pwm.duty_u16(int(65536 * pwm_right))
    motor1_forward_pin.off()
    motor1_backward_pin.on()

#Sætter dutycycle for venstre motor.
def left_backward(pwm_left):
    left_pwm.duty_u16(int(65536 * pwm_left))
    motor2_forward_pin.off()
    motor2_backward_pin.on()

#Slukker for pins til motor 1.
def stop_right():
    motor1_forward_pin.off()
    motor1_backward_pin.off()

#Slukker for pins til motor 2.
def stop_left():
    motor2_forward_pin.off()
    motor2_backward_pin.off()
