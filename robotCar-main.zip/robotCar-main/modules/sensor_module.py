from machine import Pin, ADC
import time

DISTANCE_SENSOR = Pin(26, Pin.IN)
POWER_PIN = ADC(Pin(28))
REFLECTION_SENSOR = ADC(Pin(27))
EXIT_BUTTON = Pin(15, Pin.IN, Pin.PULL_DOWN)

def read_Power():
    bat_charge = POWER_PIN.read_u16()
    value = ((bat_charge/(2.8*3.3))/65535*8.4)
    return value

# Meassures the distance in nanoseconds, and returns it in cm.
def getDistance():
    while DISTANCE_SENSOR.value() == True:
        pass
    while DISTANCE_SENSOR.value() == False:
        pass
    starttime = time.ticks_us()
    while DISTANCE_SENSOR.value() == True:
        pass
    endtime = time.ticks_us()
    diff_in_cm = (endtime - starttime) / 100

    return diff_in_cm

def check_button():
    return EXIT_BUTTON.value()

"""
Darker colours are above ~50000 while lighter colours are below
Inspired by code from - Random Nerd Tutorial
https://randomnerdtutorials.com/raspberry-pi-pico-analog-inputs-micropython/
"""

def readColour():
    value = REFLECTION_SENSOR.read_u16()
    value = round(value, 2)
    return value
