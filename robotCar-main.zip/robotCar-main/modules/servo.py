from time import sleep
from machine import Pin, PWM

pwm = PWM(Pin(16))
pwm.freq(50)

def vold():
    for position in range(4000,7000,150):
        pwm.duty_u16(position)
        sleep(0.01)
    for position in range(7000,4000,-150):
        pwm.duty_u16(position)
        sleep(0.01)

def fairplay():
    for position in range (4000,7000,150):
        pwm.duty_u16(position)
        sleep(0.01)

def foulplay():
    for position in range (7000,4000,-150):
        pwm.duty_u16(position)
        sleep(0.01)
